<?php
date_default_timezone_set("Asia/Calcutta");

$servername = "database-1.ctsrely4bvgo.ap-south-1.rds.amazonaws.com";
$username = "admin";
$password = "pawan2244";
$dbname = "system";

$timestamp = date("Y-m-d H:i:s");
$hash = substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'),0,64);
$passwd = md5('Pawan@2244');
$ssid = mt_rand(00000000000, 99999999999);


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user (ssid, name, email, password, time_stamp, encrypt, number)
VALUES ('$ssid', 'Demo', '', '$passwd', '$timestamp', '$hash', '+919546730793')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>