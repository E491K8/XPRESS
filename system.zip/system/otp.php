<?php
include "config.php";
date_default_timezone_set("Asia/Calcutta");

session_start();


$timestamp = date("Y-m-d H:i:s");
$hash = substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789'),0,64);
$otp = mt_rand(000000, 999999);
$sid = $_SESSION['SESSION_SSID'];

$sql = "UPDATE user SET otp='$otp', time_stamp='$timestamp', encrypt='$hash' WHERE ssid='$sid'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
  $_SESSION["SESSION_NEW_SSID"] = $sid;
  $_SESSION["SESSION_OTP"] = $otp;
  header("Location: sms.php");

} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>