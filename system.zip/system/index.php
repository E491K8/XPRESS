<?php

session_start();

include_once("config.php");


if (isset($_POST["login"])) {

	$ssid = mysqli_real_escape_string($conn, $_POST["ssid"]);
	$password = mysqli_real_escape_string($conn, md5($_POST["password"]));

	$sql = "select * from user where ssid = '$ssid' and password = '$password'";  
	$result = mysqli_query($conn, $sql);  
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
	$count = mysqli_num_rows($result);  
	  
	if($count == 1){  
		echo "<script>alert('Login successful redirecting......')</script>";  

		$_SESSION["SESSION_SSID"] = $ssid;
		header("Location: otp.php");
	}  
	else{  
		echo "<script>alert('Invalid SSID or Password! Please try again')</script>";  
	}     
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="style.css">
	<title>Responsive Login And Register Form</title>
</head>
<body>
	
	<div class="container">
		<form action="#" method="POST" class="login active" autocomplete="off">
			<h2 class="title">Login with your account</h2>
			<div class="form-group">
				<label for="email">SSID</label>
				<div class="input-group">
					<input type="number" name="ssid" id="email" placeholder="SSID Number">
					<i class='bx bx-user-circle'></i>
				</div>
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<div class="input-group">
					<input type="password" name="password" pattern=".{8,}" id="password" placeholder="Your password">
					<i class='bx bx-lock-alt' ></i>
				</div>
				<span class="help-text">At least 8 characters</span>
			</div>
			<button type="submit" name="login" class="btn-submit">Login</button>
		</form>

	</div>

	<script src="script.js"></script>
</body>
</html>