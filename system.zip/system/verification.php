<?php

session_start();

include_once("config.php");
$reg_ssid = $_SESSION['SESSION_SSID'];

if (isset($_POST["verify"])) {

	$otp = mysqli_real_escape_string($conn, $_POST["otp"]);

	$sql = "select * from user where ssid = '$reg_ssid' and otp = '$otp'";  
	$result = mysqli_query($conn, $sql);  
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
	$count = mysqli_num_rows($result);  
	  
	if($count == 1){  
		echo "<script>alert('Redirecting....')</script>";  

		$_SESSION["SESSION_SSID"] = $reg_ssid;
        header("Location: Admin/template/index.php");
		
	}  
	else{  
		echo "<script>alert('Incorrect OTP please try again!')</script>";  
	}     
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="style.css">
	<title>2AF VERIFICATION</title>
</head>
<body>
	
	<div class="container">
		<form action="#" method="POST" class="login active" autocomplete="off">
			<h2 class="title">2AF Verification by ZEGO SECURE</h2>
			<div class="form-group">
				<label for="password">OTP</label>
				<div class="input-group">
					<input type="password" name="otp" pattern=".{6,}" id="password" placeholder="Your 6-Digit OTP">
					<i class='bx bx-lock-alt' ></i>
				</div>
				<span class="help-text">At least 8 characters</span>
			</div>
			<a href="sms.php"><u>
			<h6 style="color: #1368E3;">Didn't get OTP? Resend </h6></u></a><br>
			<button type="submit" name="verify" class="btn-submit">Login</button>
		</form>

	</div>

	<script src="script.js"></script>
</body>
</html>